#### This content is based on the files developed by Kristian Sloth Lauszus for Sanguino

The code is released under the GNU General Public License.
_________

This content is required to add support for the stepZero board to Arduino IDE 1.6.x or later.

For more information see https://www.cannyrobots.com/documentation/